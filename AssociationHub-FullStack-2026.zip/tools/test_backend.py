import urllib.request
import urllib.error
import json
import time

BASE = "http://127.0.0.1:8080"

print("============================================================")
print("AssociationHub Automated Full-Stack Regression Suite")
print("============================================================")

# 1. Test Static Index
res = urllib.request.urlopen(f"{BASE}/")
assert res.status == 200, f"Index failed: {res.status}"
print("[PASS] 1. Index page OK (200)")

# 2. Test OpenAPI Docs
res = urllib.request.urlopen(f"{BASE}/docs")
assert res.status == 200, f"Docs failed: {res.status}"
print("[PASS] 2. FastAPI Docs OK (200)")

# 3. Test Verify Page
res = urllib.request.urlopen(f"{BASE}/verify.html")
assert res.status == 200
print("[PASS] 3. verify.html OK (200)")

# 4. Test Health & Stats Endpoints
res = urllib.request.urlopen(f"{BASE}/api/health")
health_data = json.loads(res.read())
assert health_data["status"] == "healthy"
print(f"[PASS] 4. /api/health OK: {health_data['service']} v{health_data['version']}")

res = urllib.request.urlopen(f"{BASE}/api/stats")
stats_data = json.loads(res.read())
assert stats_data["status"] == "operational"
print(f"[PASS] 5. /api/stats OK: {stats_data['total_registered_members']} members recorded")

# 5. Test Membership Pass Creation
uid = str(int(time.time()))
payload = {
    "name": "Affan Choudhari",
    "roll": f"TEST-{uid}",
    "email": f"affan_{uid}@orchidengg.ac.in",
    "dept": "Computer Science & Engineering",
    "year": "Second Year (SY)",
    "association": "CSESA",
    "interest": "Full-Stack Distributed Architecture"
}
req = urllib.request.Request(
    f"{BASE}/api/memberships",
    data=json.dumps(payload).encode(),
    headers={"Content-Type": "application/json"},
    method="POST"
)
res = urllib.request.urlopen(req)
assert res.status == 201
data = json.loads(res.read())
pass_id = data["pass_id"]
assert data["qr_code_base64"].startswith("data:image/png;base64,")
print(f"[PASS] 6. Membership Pass created: {pass_id} with Base64 QR code")

# 6. Test Duplicate Prevention (returns existing pass gracefully)
req_dup = urllib.request.Request(
    f"{BASE}/api/memberships",
    data=json.dumps(payload).encode(),
    headers={"Content-Type": "application/json"},
    method="POST"
)
res_dup = urllib.request.urlopen(req_dup)
dup_data = json.loads(res_dup.read())
assert dup_data["pass_id"] == pass_id
print(f"[PASS] 7. Duplicate request resolved cleanly with existing pass {pass_id}")

# 7. Test Quick Pass Lookup by PRN/Roll
res = urllib.request.urlopen(f"{BASE}/api/memberships/lookup?query=TEST-{uid}")
lookup_data = json.loads(res.read())
assert lookup_data["pass_id"] == pass_id
print(f"[PASS] 8. Quick Pass Lookup by Roll No OK: matched pass {lookup_data['pass_id']}")

# 8. Test Gate Pass Verification & Check-in
res = urllib.request.urlopen(f"{BASE}/api/memberships/verify/{pass_id}")
verify_data = json.loads(res.read())
assert verify_data["valid"] is True
assert verify_data["member"]["roll_no"] == f"TEST-{uid}"
print(f"[PASS] 9. Gate QR verification validated for {pass_id}")

# 9. Test Community Posts & Campus Pulse
req_post = urllib.request.Request(
    f"{BASE}/api/community/posts",
    data=json.dumps({
        "author_name": "Affan Choudhari",
        "roll_no": f"TEST-{uid}",
        "dept": "Computer Science & Engineering",
        "year": "Second Year (SY)",
        "category": "Project Collaboration",
        "title": "Autonomous Agentic AI Testing",
        "content": "Deep testing of NKOCET AssociationHub architecture.",
        "is_anonymous": False
    }).encode(),
    headers={"Content-Type": "application/json"},
    method="POST"
)
res_post = urllib.request.urlopen(req_post)
post_data = json.loads(res_post.read())
post_id = post_data["post_id"]
print(f"[PASS] 10. Community Post published: {post_id}")

# 10. Clean up test pass using Master Admin PIN
del_req = urllib.request.Request(
    f"{BASE}/api/memberships/{pass_id}?pin=admin2026",
    method="DELETE"
)
res_del = urllib.request.urlopen(del_req)
del_data = json.loads(res_del.read())
assert del_data["success"] is True
print(f"[PASS] 11. Membership pass revoked and purged cleanly")

print("\n============================================================")
print(">>> ALL 11 END-TO-END REGRESSION TESTS PASSED 100%! <<<")
print("============================================================")
