import os
import sys
import glob
import re
import sqlite3
import urllib.request
import urllib.error
import urllib.parse
import json
import time

if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

DIRECTORY = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = "http://127.0.0.1:8080"
ADMIN_PIN = "admin2026"

print("=" * 65)
print("[AUDIT] ASSOCIATIONHUB FULL-STACK CODEBASE & ARCHITECTURAL AUDIT")
print("=" * 65)

issues_found = []

# --- 1. ENCODING & ARTIFACT SCAN ---
print("\n[CHECK 1] Scanning for broken unicode characters (e.g. \ufffd, mojibake)...")
all_text_files = glob.glob(os.path.join(DIRECTORY, "*.html")) + glob.glob(os.path.join(DIRECTORY, "*.js")) + glob.glob(os.path.join(DIRECTORY, "*.css"))
for fpath in all_text_files:
    fname = os.path.basename(fpath)
    try:
        with open(fpath, "r", encoding="utf-8") as f:
            content = f.read()
            if "\ufffd" in content:
                cnt = content.count("\ufffd")
                issues_found.append(f"Encoding issue: '{fname}' has {cnt} replacement character(s) (\ufffd).")
                print(f"  [FAIL] {fname}: {cnt} replacement characters found")
            mojibake = len(re.findall(r'Â|â€[™œž˜]|Ã©', content))
            if mojibake > 0:
                issues_found.append(f"Mojibake artifacts: '{fname}' has {mojibake} potential encoding glitch(es).")
                print(f"  [WARN] {fname}: {mojibake} mojibake sequences found")
    except Exception as e:
        issues_found.append(f"Read error in {fname}: {e}")

if not issues_found:
    print("  [OK] All text files clean with zero mojibake or replacement artifacts.")

# --- 2. INTERNAL LINK & ASSET INTEGRITY SCAN ---
print("\n[CHECK 2] Auditing all internal links and asset references across HTML pages...")
for html_path in glob.glob(os.path.join(DIRECTORY, "*.html")):
    fname = os.path.basename(html_path)
    with open(html_path, "r", encoding="utf-8") as f:
        html = f.read()

    # Find hrefs
    hrefs = re.findall(r'href=["\']([^"\']+)["\']', html)
    for h in hrefs:
        if h.startswith(("http://", "https://", "mailto:", "tel:", "#", "javascript:", "/api/")) or "${" in h:
            continue
        clean_target = h.split("#")[0].split("?")[0]
        if clean_target:
            target_path = os.path.join(DIRECTORY, clean_target)
            if not os.path.exists(target_path):
                issues_found.append(f"Broken link in '{fname}': href='{h}' -> '{clean_target}' not found!")
                print(f"  [FAIL] Broken link in {fname}: href='{h}'")

    # Find srcs
    srcs = re.findall(r'src=["\']([^"\']+)["\']', html)
    for s in srcs:
        if s.startswith(("http://", "https://", "data:")):
            continue
        clean_src = s.split("?")[0]
        if not ("${" in s or "{{" in s):
            target_path = os.path.join(DIRECTORY, clean_src)
            if not os.path.exists(target_path):
                issues_found.append(f"Broken asset in '{fname}': src='{s}' not found!")
                print(f"  [FAIL] Broken asset in {fname}: src='{s}'")

print(f"  [OK] HTML internal links and static assets verified across {len(glob.glob(os.path.join(DIRECTORY, '*.html')))} pages.")

# --- 3. DATABASE INTEGRITY SCAN ---
print("\n[CHECK 3] Auditing SQLite schema, constraints, and data integrity...")
db_path = os.path.join(DIRECTORY, "associationhub.db")
if not os.path.exists(db_path):
    issues_found.append("Database file 'associationhub.db' does not exist!")
    print("  [FAIL] associationhub.db missing!")
else:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    tables = [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()]
    print(f"  Tables found ({len(tables)}): {tables}")
    required_tables = ["memberships", "registered_students", "gate_checkins", "events", "announcements", "community_posts", "account_restrictions", "security_audit_logs"]
    for req in required_tables:
        if req not in tables:
            issues_found.append(f"Table '{req}' missing in SQLite database!")

    # Check for corrupt membership records
    null_members = c.execute("SELECT COUNT(*) FROM memberships WHERE pass_id IS NULL OR name IS NULL OR roll_no IS NULL OR qr_code_base64 IS NULL;").fetchone()[0]
    if null_members > 0:
        issues_found.append(f"Database contains {null_members} corrupt membership record(s) with NULL fields!")
    else:
        print("  [OK] Membership records 100% non-null and cryptographically sound.")

    conn.close()

# --- 4. BACKEND API ENDPOINT STRESS & EDGE CASES ---
print("\n[CHECK 4] Testing Backend Edge Cases & Security Guards...")

# 4a. Health & Stats
try:
    res = urllib.request.urlopen(f"{BASE}/api/health")
    h_data = json.loads(res.read())
    assert h_data["status"] == "healthy"
    print(f"  [OK] /api/health: {h_data['service']} v{h_data['version']}")
except Exception as e:
    issues_found.append(f"Health check failed: {e}")

try:
    res = urllib.request.urlopen(f"{BASE}/api/stats")
    s_data = json.loads(res.read())
    assert s_data["status"] == "operational"
    print(f"  [OK] /api/stats: {s_data['total_registered_members']} members across {len(s_data['members_by_association'])} associations")
except Exception as e:
    issues_found.append(f"Stats check failed: {e}")

# 4b. Invalid Association Test
invalid_assoc_payload = {
    "name": "Security Auditor",
    "roll": "AUDIT-X9",
    "email": "audit_x9@orchidengg.ac.in",
    "dept": "Unknown",
    "year": "First Year (FY)",
    "association": "NOT_A_REAL_CLUB",
    "interest": "Testing validation boundary"
}
req = urllib.request.Request(
    f"{BASE}/api/memberships",
    data=json.dumps(invalid_assoc_payload).encode(),
    headers={"Content-Type": "application/json"},
    method="POST"
)
try:
    res = urllib.request.urlopen(req)
    issues_found.append("Validation issue: Backend accepted arbitrary non-existent association 'NOT_A_REAL_CLUB'!")
    print("  [WARN] Backend accepted invalid association 'NOT_A_REAL_CLUB'")
except urllib.error.HTTPError as e:
    if e.code in [400, 422]:
        print(f"  [OK] Backend properly rejected invalid association (HTTP {e.code})")

# 4c. Anti-Troll Shield Test (Vulgar language and repetitive spam)
troll_payload = {
    "author_name": "Troll User",
    "roll_no": "TEST-TROLL-1",
    "dept": "Computer Science & Engineering",
    "year": "Second Year (SY)",
    "category": "General",
    "title": "Spam Flooding aaaaaaaaaaaaa",
    "content": "This is spam character flood aaaaaaaaaaaaaaaaaaaaa",
    "is_anonymous": False
}
req_troll = urllib.request.Request(
    f"{BASE}/api/community/posts",
    data=json.dumps(troll_payload).encode(),
    headers={"Content-Type": "application/json"},
    method="POST"
)
try:
    res_troll = urllib.request.urlopen(req_troll)
    issues_found.append("Anti-troll shield failed to reject character flood!")
    print("  [FAIL] Anti-troll shield failed to reject character flood!")
except urllib.error.HTTPError as e:
    if e.code == 400:
        print(f"  [OK] Campus Anti-Troll Shield active: Rejected character flood (HTTP 400)")

# 4d. Master Admin PIN Authentication Security
pin_req = urllib.request.Request(
    f"{BASE}/api/admin/verify-pin",
    data=json.dumps({"pin": "wrong_pin_attempt"}).encode(),
    headers={"Content-Type": "application/json"},
    method="POST"
)
try:
    urllib.request.urlopen(pin_req)
    issues_found.append("Security issue: Unauthorized access permitted with invalid PIN!")
except urllib.error.HTTPError as e:
    if e.code in [401, 403]:
        print(f"  [OK] Admin Security Gate active: Unauthorized access rejected (HTTP {e.code})")

# --- SUMMARY ---
print("\n" + "=" * 65)
print(f"AUDIT COMPLETE: Found {len(issues_found)} issue(s):")
if not issues_found:
    print(">>> ZERO DEFECTS FOUND: ALL SYSTEM CHECKS & INTEGRATIONS PASSED 100%! <<<")
else:
    for idx, iss in enumerate(issues_found, 1):
        print(f"  {idx}. {iss}")
print("=" * 65)
