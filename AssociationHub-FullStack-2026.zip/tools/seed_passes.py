import sqlite3
import qrcode
import io
import base64

conn = sqlite3.connect(r"C:\Users\affan\.gemini\antigravity\scratch\nkocet-website\associationhub.db")
c = conn.cursor()

def make_qr(url):
    qr = qrcode.QRCode(version=1, box_size=8, border=2)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="#080A0F", back_color="#FFFFFF")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()

demo_passes = [
    ("NKOCET-2026-CSESA-A2B4C6", "Suyash Gote", "C-64", "Computer Science & Engineering", "Second Year (SY)", "CSESA", "UI/UX Architecture & Design Systems"),
    ("NKOCET-2026-AIESA-D3E5F7", "Umair Shaikh", "C-54", "Artificial Intelligence & Data Science", "Second Year (SY)", "AIESA", "Deep Learning & Neural Networks"),
    ("NKOCET-2026-MESA-B8C9D0", "Moin Shaikh", "C-67", "Mechanical Engineering", "Second Year (SY)", "MESA", "Robotics & Automation"),
    ("NKOCET-2026-EESA-F1G2H3", "Sushil Habib", "C-58", "Electrical Engineering", "Second Year (SY)", "EESA", "Smart Grids & Renewable Energy"),
    ("NKOCET-2026-CESA-K4L5M6", "Siddeshwar Nagansure", "C-61", "Civil Engineering", "Second Year (SY)", "CESA", "CAD Modeling & Structural Analysis")
]

for pid, name, roll, dept, yr, assoc, interest in demo_passes:
    qr = make_qr(f"http://127.0.0.1:8080/verify.html?pass_id={pid}")
    c.execute("""
    INSERT OR IGNORE INTO memberships (pass_id, name, roll_no, dept, year, association, interest, qr_code_base64, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, "2026-10-31 16:00:00");
    """, (pid, name, roll, dept, yr, assoc, interest, qr))

conn.commit()
count = c.execute("SELECT COUNT(*) FROM memberships").fetchone()[0]
print(f"Total memberships in DB: {count}")
conn.close()
