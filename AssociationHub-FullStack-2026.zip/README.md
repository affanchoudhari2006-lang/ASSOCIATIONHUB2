# AssociationHub — NK Orchid College of Engineering & Technology

> **2nd Year, 3rd Semester B.Tech — College Engagement Project (CEP)**  
> *Core Mission: Spreading awareness about department associations, technical clubs, laboratories, and collegiate events among freshers at NKOCET Solapur.*

---

## 🚀 Overview

**AssociationHub** is the unified digital portal designed and developed for N.K. Orchid College of Engineering & Technology (NKOCET), Solapur. It bridges incoming junior students with the campus engineering community, providing comprehensive directories, laboratory specifications, verified historical symposium records, and participation pathways.

---

## 🎨 Creative Direction & Cinematic Theme

Built on a **futuristic cinematic dark theme**, the portal utilizes modular glassmorphism, responsive architectural grids, and department-specific color identities:

* **Global Palette**:
  - Obsidian Black: `#080A0F`
  - Midnight Navy: `#0D1220`
  - Charcoal Surface: `#151923`
  - Elevated Surface: `#1B2230`
  - Primary Text: `#F4F6FA`
  - Subtle Borders: `#293142`
  - Shared College Accent: Muted Gold (`#E5A93C`)

* **Department Identities**:
  1. **CSESA** (Computer Science & Engineering) — **Cyber Blue `#1687FF`**
  2. **MESA** (Mechanical Engineering) — **Industrial Orange `#FF8A24`**
  3. **EESA** (Electrical Engineering) — **Electric Emerald `#19D68C`**
  4. **CESA** (Civil Engineering) — **Architectural Violet `#A855F7`**
  5. **AEXS** (Electronics & Telecommunication) — **Signal Crimson `#FF416C`**
  6. **AIESA** (Artificial Intelligence & Data Science) — **Neural Cyan `#00D9E8`**

---

## 📂 File Architecture

```text
cep-website-main/
│
├── index.html            # Main Portal Homepage with Live Search, Filter & Events
├── cep-about us.html     # Project Team, Mission, Vision & Academic Background
│
├── cep-cesa.html         # CSESA — Computer Science & Engineering Association
├── cep-mesa.html         # MESA  — Mechanical Engineering Students Association
├── esa.html              # EESA  — Electrical Engineering Students Association
├── civil.html            # CESA  — Civil Engineering Students Association
├── entc.html             # AEXS  — Electronics & Telecommunication Association
├── aids.html             # AIESA — AI & Data Science Association
│
├── css.css               # Unified Design System & Master Responsive Stylesheet
├── main.js               # Interactive Engine (Mobile Nav, Filter, Lightbox, Tabs)
│
├── nkocet logo.png.webp  # Official College Logo Asset
├── akil.jpeg             # Campus Gallery Archive Asset
├── akil-aboutus.jpg      # Campus Gallery Archive Asset
├── nilesh.jpg            # Campus Gallery Archive Asset
├── param.jpeg            # Campus Gallery Archive Asset
├── san.jpeg              # Campus Gallery Archive Asset
├── sura.jpeg             # Campus Gallery Archive Asset
└── README.md             # Project Documentation
```

---

## 👥 Project Team

* **Affan Choudhari** — Roll No. C-62 (Project Lead)
* **Suyash Gote** — Roll No. C-64 (UI/UX Lead)
* **Umair Shaikh** — Roll No. C-54 (Research Lead)
* **Moin Shaikh** — Roll No. C-67 (Systems Lead)
* **Sushil Habib** — Roll No. C-58 (Verification)
* **Siddeshwar Nagansure** — Roll No. C-61 (Documentation)

---

## 💻 How to Run Locally

You can run AssociationHub in any modern web browser without dependencies or package installations:

```bash
# Using Python built-in HTTP server:
python -m http.server 8000

# Open in your browser:
http://localhost:8000
```
Or simply double-click `index.html` to open in any web browser.
